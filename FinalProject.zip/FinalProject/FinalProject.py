# imports
from tkinter import *
from PIL import ImageTk, Image
import data

# Set up the main window
root = Tk()
root.title("Morrowind Directory")
root.iconbitmap("images/MW.ico")
root.geometry("{}x{}".format(1150, 750))
root.configure(bg="#000000")


# Function for the show info buttons. Clears the frame of image to replace with text box. Uses other file
# data.py to store the text
def showInfo(locationName, imageFilePath, frame):
    for widget in frame.winfo_children():
        widget.destroy()
    locationText = Text(frame, bg="#5C4033", fg="#ffffff", wrap=WORD)
    locationText.place(x=0, y=27, height=350, width=360)
    locationText.insert("1.0", data.textDescription[locationName])
    locationLabel = Label(frame, text=locationName, font="MSSerif", padx=50, bg="#988558", fg="white")
    locationLabel.place(relx=0.5, rely=0.001, anchor=N)
    locationButton = Button(frame, text="Show image", command=lambda: showImage(locationName=locationName,
                                                                     imageFilePath=imageFilePath, frame=frame))
    locationButton.place(relx=0.5, rely=1.0, anchor=S)


# Function for the show info buttons. Is supposed to clear the frame of info text to replace with image but currently
# does not work
def showImage(locationName, imageFilePath, frame):
    for widget in frame.winfo_children():
        widget.destroy()
    locationImage = ImageTk.PhotoImage(Image.open(imageFilePath))
    newImgLabel = Label(frame, image=locationImage)
    newImgLabel.grid(row=0, column=0)
    locationLabel = Label(frame, text=locationName, font="MSSerif", padx=50, bg="#988558", fg="white")
    locationLabel.place(relx=0.5, rely=0.001, anchor=N)
    locationButton = Button(frame, text="Show info", command=lambda: showInfo(locationName=locationName,
                                                                      imageFilePath=imageFilePath, frame=frame))
    locationButton.place(relx=0.5, rely=1.0, anchor=S)

# Function for the open regions command and the region window
def openRegions():
    # Making images global inside the function is the only way I found to get them to appear properly, without this
    # the images would not appear in new windows
    global ascadianImage
    global ashlandsImage
    global azuraImage
    global bitterImage
    global grazeImage
    global molagImage
    global redImage
    global sheoImage
    global westImage
    # Sets up the Regions window
    Regions = Toplevel()
    root.iconify()
    Regions.geometry("1100x750")
    Regions.configure(bg="#000000")
    Regions.title("Regions of Vvardenfell")
    # Exit button closes the region window and brings the main window back up
    exitButtonRe = Button(Regions, text="Back to Menu", bg="#EADDCA", command=lambda: [Regions.destroy(), root.deiconify()])
    exitButtonRe.grid(row=3, column=0, columnspan=3)
    exitButtonRe.config(height=7, width=156)
    # Creates frames for the regions
    ascadianFrame = LabelFrame(Regions, bd=0.5, bg="#5C4033", width=350, height=202, padx=5, pady=5)
    ashlandsFrame = LabelFrame(Regions, bd=0.5, bg="#5C4033", width=350, height=202, padx=5, pady=5)
    azuraFrame = LabelFrame(Regions, bd=0.5, bg="#5C4033", width=350, height=202, padx=5, pady=5)
    bitterFrame = LabelFrame(Regions, bd=0.5, bg="#5C4033", width=350, height=202, padx=5, pady=5)
    grazeFrame = LabelFrame(Regions, bd=0.5, bg="#5C4033", width=350, height=202, padx=5, pady=5)
    molagFrame = LabelFrame(Regions, bd=0.5, bg="#5C4033", width=350, height=202, padx=5, pady=5)
    redFrame = LabelFrame(Regions, bd=0.5, bg="#5C4033", width=350, height=202, padx=5, pady=5)
    sheoFrame = LabelFrame(Regions, bd=0.5, bg="#5C4033", width=350, height=202, padx=5, pady=5)
    westFrame = LabelFrame(Regions, bd=0.5, bg="#5C4033", width=350, height=202, padx=5, pady=5)
    # Places the frames in a grid on the screen
    ascadianFrame.grid(row=0, column=0)
    ashlandsFrame.grid(row=0, column=1)
    azuraFrame.grid(row=0, column=2)
    bitterFrame.grid(row=1, column=0)
    grazeFrame.grid(row=1, column=1)
    molagFrame.grid(row=1, column=2)
    redFrame.grid(row=2, column=0)
    sheoFrame.grid(row=2, column=1)
    westFrame.grid(row=2, column=2)

    # Creates images to be placed inside each frame
    ascadianImage = ImageTk.PhotoImage(Image.open("images/Regions/ascadian-isles_350x202.jpg"))
    ascadianImgLabel = Label(ascadianFrame, image=ascadianImage)
    ascadianImgLabel.grid(row=0, column=0)
    ashlandsImage = ImageTk.PhotoImage(Image.open("images/Regions/ashlands_350x202.jpg"))
    ashlandsImgLabel = Label(ashlandsFrame, image=ashlandsImage)
    ashlandsImgLabel.grid(row=0, column=1)
    azuraImage = ImageTk.PhotoImage(Image.open("images/Regions/azuras_coast_350x202.jpg"))
    azuraImgLabel = Label(azuraFrame, image=azuraImage)
    azuraImgLabel.grid(row=0, column=2)
    bitterImage = ImageTk.PhotoImage(Image.open("images/Regions/Bitter-Coast2_350x202.jpg"))
    bitterImgLabel = Label(bitterFrame, image=bitterImage)
    bitterImgLabel.grid(row=1, column=0)
    grazeImage = ImageTk.PhotoImage(Image.open("images/Regions/grazelands_350x202.jpg"))
    grazeImgLabel = Label(grazeFrame, image=grazeImage)
    grazeImgLabel.grid(row=1, column=1)
    molagImage = ImageTk.PhotoImage(Image.open("images/Regions/molagamur2_350x202.jpg"))
    molagImgLabel = Label(molagFrame, image=molagImage)
    molagImgLabel.grid(row=1, column=2)
    redImage = ImageTk.PhotoImage(Image.open("images/Regions/redmountain2_1_350x202.jpg"))
    redImgLabel = Label(redFrame, image=redImage)
    redImgLabel.grid(row=2, column=0)
    sheoImage = ImageTk.PhotoImage(Image.open("images/Regions/sheogorad3_350x202.jpg"))
    sheoImgLabel = Label(sheoFrame, image=sheoImage)
    sheoImgLabel.grid(row=2, column=1)
    westImage = ImageTk.PhotoImage(Image.open("images/Regions/westgash2_350x202.jpg"))
    westImgLabel = Label(westFrame, image=westImage)
    westImgLabel.grid(row=2, column=2)

    # Creates labels for each frame displaying the name of the region
    ascadianLabel = Label(ascadianFrame, text="Ascadian Isles", font="MSSerif", padx=50, bg="#988558", fg="white")
    ascadianLabel.place(relx=0.5, rely=0.001, anchor=N)
    ashlandsLabel = Label(ashlandsFrame, text="Ashlands", font="MSSerif", padx=50, bg="#988558", fg="white")
    ashlandsLabel.place(relx=0.5, rely=0.001, anchor=N)
    azuraLabel = Label(azuraFrame, text="Azura's Coast", font="MSSerif", padx=50, bg="#988558", fg="white")
    azuraLabel.place(relx=0.5, rely=0.001, anchor=N)
    bitterLabel = Label(bitterFrame, text="Bitter Coast", font="MSSerif", padx=50, bg="#988558", fg="white")
    bitterLabel.place(relx=0.5, rely=0.001, anchor=N)
    grazeLabel = Label(grazeFrame, text="Grazelands", font="MSSerif", padx=50, bg="#988558", fg="white")
    grazeLabel.place(relx=0.5, rely=0.001, anchor=N)
    molagLabel = Label(molagFrame, text="Molag Amur", font="MSSerif", padx=50, bg="#988558", fg="white")
    molagLabel.place(relx=0.5, rely=0.001, anchor=N)
    redLabel = Label(redFrame, text="Red Mountain", font="MSSerif", padx=50, bg="#988558", fg="white")
    redLabel.place(relx=0.5, rely=0.001, anchor=N)
    sheoLabel = Label(sheoFrame, text="Sheogorad", font="MSSerif", padx=50, bg="#988558", fg="white")
    sheoLabel.place(relx=0.5, rely=0.001, anchor=N)
    westLabel = Label(westFrame, text="West Gash", font="MSSerif", padx=50, bg="#988558", fg="white")
    westLabel.place(relx=0.5, rely=0.001, anchor=N)

    # Creates the show info/show image button
    ascadianButton = Button(ascadianFrame, text="Show Info",
                            command=lambda: showInfo(locationName="Ascadian Isles",
                            frame=ascadianFrame, imageFilePath="images/Regions/ascadian-isles_350x202.jpg"))
    ascadianButton.place(relx=0.5, rely=1.0, anchor=S)
    ashlandsButton = Button(ashlandsFrame, text="Show Info",
                            command=lambda: showInfo(locationName="Ashlands",
                            frame=ashlandsFrame, imageFilePath="images/Regions/ashlands_350x202.jpg"))
    ashlandsButton.place(relx=0.5, rely=1.0, anchor=S)
    azuraButton = Button(azuraFrame, text="Show Info",
                         command=lambda: showInfo(locationName="Azura's Coast",
                         frame=azuraFrame, imageFilePath="images/Regions/azuras_coast_350x202.jpg"))
    azuraButton.place(relx=0.5, rely=1.0, anchor=S)
    bitterButton = Button(bitterFrame, text="Show Info",
                          command=lambda: showInfo(locationName="Bitter Coast",
                          frame=bitterFrame, imageFilePath="images/Regions/Bitter-Coast2_350x202.jpg"))
    bitterButton.place(relx=0.5, rely=1.0, anchor=S)
    grazeButton = Button(grazeFrame, text="Show Info",
                         command=lambda: showInfo(locationName="Grazelands",
                         frame=grazeFrame, imageFilePath="images/Regions/grazelands_350x202.jpg"))
    grazeButton.place(relx=0.5, rely=1.0, anchor=S)
    molagButton = Button(molagFrame, text="Show Info",
                         command=lambda: showInfo(locationName="Molag Amur",
                         frame=molagFrame, imageFilePath="images/Regions/molagamur2_350x202.jpg"))
    molagButton.place(relx=0.5, rely=1.0, anchor=S)
    redButton = Button(redFrame, text="Show Info",
                       command=lambda: showInfo(locationName="Red Mountain",
                       frame=redFrame, imageFilePath="images/Regions/redmountain2_1_350x202.jpg"))
    redButton.place(relx=0.5, rely=1.0, anchor=S)
    sheoButton = Button(sheoFrame, text="Show Info",
                        command=lambda: showInfo(locationName="Sheogorad",
                        frame=sheoFrame, imageFilePath="images/Regions/sheogorad3_350x202.jpg"))
    sheoButton.place(relx=0.5, rely=1.0, anchor=S)
    westButton = Button(westFrame, text="Show Info",
                        command=lambda: showInfo(locationName="West Gash",
                        frame=westFrame, imageFilePath="images/Regions/westgash2_350x202.jpg"))
    westButton.place(relx=0.5, rely=1.0, anchor=S)


# Function for the open cities command and the cities window
def openCities():
    # Making images global inside the function is the only way I found to get them to appear properly, without this
    # the images would not appear in new windows
    global aldImage
    global balmoraImage
    global calderaImage
    global dagonImage
    global ebonheartImage
    global gnisisImage
    global sadrithImage
    global suranImage
    global vivecImage
    # Sets up the cities window
    Cities = Toplevel()
    root.iconify()
    Cities.geometry("1100x750")
    Cities.configure(bg="#000000")
    Cities.title("Cities of Vvardenfell")
    # Exit button closes the cities window and brings the main window back up
    exitButtonRe = Button(Cities, text="Back to Menu", bg="#EADDCA",
                          command=lambda: [Cities.destroy(), root.deiconify()])
    exitButtonRe.grid(row=3, column=0, columnspan=3)
    exitButtonRe.config(height=7, width=156)
    # Creates the frames for each city
    aldFrame = LabelFrame(Cities, bd=0.5, bg="#5C4033", width=350, height=202, padx=5, pady=5)
    balmoraFrame = LabelFrame(Cities, bd=0.5, bg="#5C4033", width=350, height=202, padx=5, pady=5)
    calderaFrame = LabelFrame(Cities, bd=0.5, bg="#5C4033", width=350, height=202, padx=5, pady=5)
    dagonFrame = LabelFrame(Cities, bd=0.5, bg="#5C4033", width=350, height=202, padx=5, pady=5)
    ebonheartFrame = LabelFrame(Cities, bd=0.5, bg="#5C4033", width=350, height=202, padx=5, pady=5)
    gnisisFrame = LabelFrame(Cities, bd=0.5, bg="#5C4033", width=350, height=202, padx=5, pady=5)
    sadrithFrame = LabelFrame(Cities, bd=0.5, bg="#5C4033", width=350, height=202, padx=5, pady=5)
    suranFrame = LabelFrame(Cities, bd=0.5, bg="#5C4033", width=350, height=202, padx=5, pady=5)
    vivecFrame = LabelFrame(Cities, bd=0.5, bg="#5C4033", width=350, height=202, padx=5, pady=5)
    # Places the frames in a grid on screen
    aldFrame.grid(row=0, column=0)
    balmoraFrame.grid(row=0, column=1)
    calderaFrame.grid(row=0, column=2)
    dagonFrame.grid(row=1, column=0)
    ebonheartFrame.grid(row=1, column=1)
    gnisisFrame.grid(row=1, column=2)
    sadrithFrame.grid(row=2, column=0)
    suranFrame.grid(row=2, column=1)
    vivecFrame.grid(row=2, column=2)
    # Sets up the cities images
    aldImage = ImageTk.PhotoImage(Image.open("images/Cities/aldruhn2_350x202.jpg"))
    aldImgLabel = Label(aldFrame, image=aldImage)
    aldImgLabel.grid(row=0, column=0)
    balmoraImage = ImageTk.PhotoImage(Image.open("images/Cities/balmora2_350x202.jpg"))
    balmoraImgLabel = Label(balmoraFrame, image=balmoraImage)
    balmoraImgLabel.grid(row=0, column=1)
    calderaImage = ImageTk.PhotoImage(Image.open("images/Cities/calderal_350x202.jpg"))
    calderaImgLabel = Label(calderaFrame, image=calderaImage)
    calderaImgLabel.grid(row=0, column=2)
    dagonImage = ImageTk.PhotoImage(Image.open("images/Cities/dagonfel_350x202.jpg"))
    dagonImgLabel = Label(dagonFrame, image=dagonImage)
    dagonImgLabel.grid(row=1, column=0)
    ebonheartImage = ImageTk.PhotoImage(Image.open("images/Cities/ebonheart2_350x202.jpg"))
    ebonheartImgLabel = Label(ebonheartFrame, image=ebonheartImage)
    ebonheartImgLabel.grid(row=1, column=1)
    gnisisImage = ImageTk.PhotoImage(Image.open("images/Cities/gnisis_350x202.jpg"))
    gnisisImgLabel = Label(gnisisFrame, image=gnisisImage)
    gnisisImgLabel.grid(row=1, column=2)
    sadrithImage = ImageTk.PhotoImage(Image.open("images/Cities/sadrith_350x202.jpg"))
    sadrithImgLabel = Label(sadrithFrame, image=sadrithImage)
    sadrithImgLabel.grid(row=2, column=0)
    suranImage = ImageTk.PhotoImage(Image.open("images/Cities/suran_350x202.jpg"))
    suranImgLabel = Label(suranFrame, image=suranImage)
    suranImgLabel.grid(row=2, column=1)
    vivecImage = ImageTk.PhotoImage(Image.open("images/Cities/vivec_350x202.jpg"))
    vivecImgLabel = Label(vivecFrame, image=vivecImage)
    vivecImgLabel.grid(row=2, column=2)
    # Cities labels displaying the name of each city
    aldLabel = Label(aldFrame, text="Ald'ruhn", font="MSSerif", padx=50, bg="#988558", fg="white")
    aldLabel.place(relx=0.5, rely=0.001, anchor=N)
    balmoraLabel = Label(balmoraFrame, text="Balmora", font="MSSerif", padx=50, bg="#988558", fg="white")
    balmoraLabel.place(relx=0.5, rely=0.001, anchor=N)
    calderaLabel = Label(calderaFrame, text="Caldera", font="MSSerif", padx=50, bg="#988558", fg="white")
    calderaLabel.place(relx=0.5, rely=0.001, anchor=N)
    dagonLabel = Label(dagonFrame, text="Dagon Fel", font="MSSerif", padx=50, bg="#988558", fg="white")
    dagonLabel.place(relx=0.5, rely=0.001, anchor=N)
    ebonheartLabel = Label(ebonheartFrame, text="Ebonheart", font="MSSerif", padx=50, bg="#988558", fg="white")
    ebonheartLabel.place(relx=0.5, rely=0.001, anchor=N)
    gnisisLabel = Label(gnisisFrame, text="Gnisis", font="MSSerif", padx=50, bg="#988558", fg="white")
    gnisisLabel.place(relx=0.5, rely=0.001, anchor=N)
    sadrithLabel = Label(sadrithFrame, text="Sadrith Mora", font="MSSerif", padx=50, bg="#988558", fg="white")
    sadrithLabel.place(relx=0.5, rely=0.001, anchor=N)
    suranLabel = Label(suranFrame, text="Suran", font="MSSerif", padx=50, bg="#988558", fg="white")
    suranLabel.place(relx=0.5, rely=0.001, anchor=N)
    vivecLabel = Label(vivecFrame, text="Vivec City", font="MSSerif", padx=50, bg="#988558", fg="white")
    vivecLabel.place(relx=0.5, rely=0.001, anchor=N)

    # Sets up the show info/show image buttons for the cities
    aldButton = Button(aldFrame, text="Info",
                       command=lambda: showInfo(locationName="Ald'ruhn",
                       frame=aldFrame, imageFilePath="images/Cities/aldruhn2_350x202.jpg"))
    aldButton.place(relx=0.5, rely=1.0, anchor=S)
    balmoraButton = Button(balmoraFrame, text="Info",
                           command=lambda: showInfo(locationName="Balmora",
                           frame=balmoraFrame, imageFilePath="images/Cities/balmora2_350x202.jpg"))
    balmoraButton.place(relx=0.5, rely=1.0, anchor=S)
    calderaButton = Button(calderaFrame, text="Info",
                           command=lambda: showInfo(locationName="Caldera",
                           frame=calderaFrame, imageFilePath="images/Cities/calderal_350x202.jpg"))
    calderaButton.place(relx=0.5, rely=1.0, anchor=S)
    dagonButton = Button(dagonFrame, text="Info",
                         command=lambda: showInfo(locationName="Dagon Fel",
                         frame=dagonFrame, imageFilePath="images/Cities/dagonfel_350x202.jpg"))
    dagonButton.place(relx=0.5, rely=1.0, anchor=S)
    ebonheartButton = Button(ebonheartFrame, text="Info",
                             command=lambda: showInfo(locationName="Ebonheart",
                             frame=ebonheartFrame, imageFilePath="images/Cities/ebonheart2_350x202.jpg"))
    ebonheartButton.place(relx=0.5, rely=1.0, anchor=S)
    gnisisButton = Button(gnisisFrame, text="Info",
                          command=lambda: showInfo(locationName="Gnisis",
                          frame=gnisisFrame, imageFilePath="images/Cities/gnisis_350x202.jpg"))
    gnisisButton.place(relx=0.5, rely=1.0, anchor=S)
    sadrithButton = Button(sadrithFrame, text="Info",
                           command=lambda: showInfo(locationName="Sadrith Mora",
                           frame=sadrithFrame, imageFilePath="images/Cities/sadrith_350x202.jpg"))
    sadrithButton.place(relx=0.5, rely=1.0, anchor=S)
    suranButton = Button(suranFrame, text="Info",
                         command=lambda: showInfo(locationName="Suran",
                         frame=suranFrame, imageFilePath="images/Cities/suran_350x202.jpg"))
    suranButton.place(relx=0.5, rely=1.0, anchor=S)
    vivecButton = Button(vivecFrame, text="Info",
                         command=lambda: showInfo(locationName="Vivec City",
                         frame=vivecFrame, imageFilePath="images/Cities/vivec_350x202.jpg"))
    vivecButton.place(relx=0.5, rely=1.0, anchor=S)


# Opens the image for the root window
introImage = Image.open("images/Vvardenfell2_1080x1080.jpg")
# Resize image to fit on screen
resized = introImage.resize((1000, 750), Image.ANTIALIAS)
introImage = ImageTk.PhotoImage(resized)
# Label for main screen image
myLabel = Label(root, image=introImage, bg="#000000")
myLabel.grid(row=0, column=0, rowspan=4)

# Configures buttons on main screen to open the other two windows, and an exit button to close the program
regionButton = Button(root, text="Regions of Vvardenfell", command=openRegions, bg="#EADDCA")
citiesButton = Button(root, text="Cities of Vvardenfell", command=openCities, bg="#EADDCA")
exitButton = Button(root, text="Exit Program", command=root.quit, bg="#EADDCA")

# Puts the buttons on the screen
regionButton.grid(row=0, column=1, sticky=N)
regionButton.config(height=16, width=20)
citiesButton.grid(row=1, column=1, sticky=N)
citiesButton.config(height=16, width=20)
exitButton.grid(row=3, column=1, sticky=N)
exitButton.config(height=16, width=20)


mainloop()
