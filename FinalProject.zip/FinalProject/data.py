textDescription = {
    "Ascadian Isles": "The Ascadian Isles are fertile, lush agricultural lowlands mainly under House Hlaalu "
                "control in Vvardenfell's southwestern area. The land is rich in nutrients, and therefore littered "
                "with small farms and plantations. Many of the councilors of Great House Hlaalu maintain plantations "
                "in the Isles to exploit the region's good growing soil, and to breed netch for their leather.",
    "Ashlands": "The Ashlands region is a dry, inhospitable  wasteland characterized by clusters of stone obelisks, " 
                "bubbling ash mires, and frequent ash storms which limit visibility and spread the Blight. The Ashlands"
                " are thus largely devoid of permanent occupied settlements. Nomadic Ashlander tribes eke out an "
                "existence here, their herds find sparse grazing around ragged tent villages in the far north.",
    "Azura's Coast": "Azura's Coast consists mainly of the numerous islands to the south and east of "
                "Vvardenfell. The area is desolate, and most of the territory is claimed by House Telvanni. "
                "It is a land mostly exempt from the laws of the Empire or the Tribunal. Since the Telvanni lords "
                "are 1000s of years old and very powerful, they tend to see the gods of the Tribunal as peers "
                "rather than supreme beings.",
    "Bitter Coast": "The Bitter Coast is the name of Vvardenfell's southwestern coastline. This largely uninhabited "
                "area is dominated by humid, putrid swamps and salt marshes. Also known as The Smuggler's Coast, "
                "the secluded coves and islands here are littered with smugglers operating out of their hidden caves, "
                "bringing alcohol, skooma, and other illicit goods into Vvardenfell.",
    "Grazelands": "The Grazelands are the pastoral heartland of Vvardenfell on the northeastern corner of the island. "
                "Much of the Grazelands is uninhabited and thus belongs to the Temple. The population of the "
                "Grazelands consists mostly of nomadic Ashlanders. Other inhabitants include those who live in "
                "the Telvanni town of Tel Vos, who have a strained relationship with their ashlander neighbors.",
    "Molag Amur": "Molag Amur is essentially the southern part of the Ashlands, distinguished from "
                "the northern Ashlands by the presence of lava pools and rivers on the surface. The land is "
                "mainly volcanic rock covered with ash and cinder. The region cannot be said to be  "
                "dominated by any House; Molag Amur is generally an area one passes through out of necessity, not a "
                "place any but the desperate would make home.",
    "Red Mountain": "Red Mountain is a volcano that dominates the island of Vvardenfell; it is the second "
                "highest mountain in Tamriel. Access to  Red Mountain is restricted: the Tribunal has built the "
                "Ghostfence, a giant Spirit Wall, around the perimeter of the mountain. Within the Ghostfence lies a "
                "wasteland where blighted monsters run free and the minions of Dagoth Ur, known as ash creatures, "
                "roam the land.",
    "Sheogorad": "Sheogorad is a wild province consisting of about 28 islands off the north coast of Vvardenfell. "
                "The area is characterized by the hundreds of jagged rocks, jutting from the ground benesth the water, "
                "either just exposed, or lying just below the surface, which makes marine navigation very risky."
                " The only accessible port, Dagon Fel, is reached by skirting the region and coming in from the north.",
    "West Gash": "The western highlands of Vvardenfell are called the West Gash. The terrain is generally rocky "
                "scrubland in the south, marked by unique, natural rock bridges inland in the south and on the coast, "
                "with sparse forest in the northern area. The Gash is mainly under House Redoran control, so the "
                "exploration of the Caldera Mine by House Hlaalu is a thorn in the eye of the Redorans.",
    "Ald'ruhn": "The town of Ald'ruhn is a dusty cluster of buildings nestled against the southwest slopes of "
                "Red Mountain. Ald'ruhn recently became the council seat of House Redoran, and all of the councilors "
                "maintain expansive mansions inside the hollowed shell of an ancient Emperor land-crab known as Skar, "
                "which the town is built around.",
    "Balmora": "Balmora  is the district seat of House Hlaalu, and the second largest settlement on Vvardenfell. "
                "Balmora is located at the southernmost edge of the West Gash. The Odai River runs through its heart "
                "and divides it into four districts: High Town, the Commercial District, Labor Town, and the nearby "
                "Imperial Legion Fort Moonmoth.",
    "Caldera": "Caldera is an Imperial charter town just north of Balmora. It was built to service the nearby Ebony "
                "mine, providing the miners with homes, entertainment, and other services. The town is ruled largely "
                "from the Caldera Mining Company's fortress to the southwest. Notable institutions include "
                "a Mages Guild branch, an orcish manor, and one of the few Imperial-style tailors in Vvardenfell.",
    "Dagon Fel": "Dagon Fel is the northernmost town in Vvardenfell, situated on the island of Sheogorad. It is home "
                "to Nord fishermen, as well as a detachment of Imperial Legion guards. There is a tiny inn with warm "
                "beds and a few traders. The most interesting things in Dagon Fel are the three Dwemer towers outside "
                "the city. Strict laws prevent the trading of Dwemer artifacts taken illegally from the ruins.",
    "Ebonheart": "Ebonheart is the seat of Imperial authority in Vvardenfell. From this city, the Duke of Ebonheart, "
                "Vedam Dren, and his Grand Council determine law and policy for the Vvardenfell district. Because "
                "the East Empire Company is chartered directly by the Emperor, its offices, warehouses and docks are "
                "adjacent to the castle, and its security is assured by the Imperial garrisons.",
    "Gnisis": " Gnisis is the largest town in the northwestern area of Vvardenfell. The town is built on a small plain "
                "on a hillside, below a large eggmine. There is a tribunal temple here, one of the stops for pilgrims"
                "visiting the Seven Graces. The Imperial Legion also maintains a sizeable garrison here at Fort Darius",
    "Sadrith Mora": "Sadrith Mora is the district seat of House Telvanni, and home of the Telvanni Council, though only "
                "1 councilor actually lives in town. Sadrith Mora is an island settlement built in typical "
                "Telvanni style: great, magically-formed mushrooms spring from the ground, each being expanded to suit"
                " the needs of the inhabitant. Non-Telvanni visitors are typically not allowed inside the city.",
    "Suran": "Suran is a medium-sized town situated on the eastern coast of Lake Masobi, within the Ascadian Isles. "
                "Its architecture resembles a typical Hlaalu market town, complete with a watchtower and a small temple. "
                "Suran typically serves as a stopover for adventureres and pilgrims heading northeast into the Molag "
                "Amur region and Mount Kand.",
    "Vivec City": "Vivec, named after the god of the same name, is the largest city in Vvardenfell and is situated on its "
                "southern coast. The city is a collection of nine artificial islands; each island is a separate district "
                "or canton and is made up of a large multi-tiered building the size of a small town. "
                "The entire city of Vivec is considered a holy place, as it is home to the Living God Vivec himself. "
}


